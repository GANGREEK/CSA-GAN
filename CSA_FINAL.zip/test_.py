

while True:
    pass
