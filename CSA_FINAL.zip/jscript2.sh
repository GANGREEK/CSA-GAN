#!/bin/bash

####prerungl

#PBS -u satish
#PBS -N nand
#PBS -l select=2:ncpus=20:ngpus=1
#PBS -e error.log
#PBS -o output.log
#PBS -q gpu


module use /home/satish/privatemodules/
module load torch12

cd $PBS_O_WORKDIR


python  test.py --dataroot ./datasets/WHU --name WHU30#1  --model attention_gan --dataset_mode aligned  --batch_size 1 --gpu_ids 0 &&

python  test.py --dataroot ./datasets/CUCK --name  CUCK30#1  --model attention_gan --dataset_mode aligned  --batch_size 1 --gpu_ids 1 &
python test_.py
#python  train.py --dataroot ./datasets/AR --name  AR220  --model  attention_gan  --dataset_mode aligned --norm instance --load_size 286 --crop_size  256  --batch_size 1 --gpu_ids 0   &

#python  train.py --dataroot ./datasets/CUCK --name CUCK220 --model  attention_gan  --dataset_mode aligned --norm instance  --load_size 286 --crop_size  256  --batch_size 1 --gpu_ids 1  &&

#python  train.py --dataroot ./datasets/WHU --name WHU220 --model  attention_gan  --dataset_mode aligned --norm instance--load_size 286 --crop_size  256  --batch_size 1 --gpu_ids 1   #&&

 

#python  train.py --dataroot ./datasets/AR --name  AR220  --model attention_gan --dataset_mode aligned --pool_size 50 --no_dropout --norm instance --lambda_A 10 --lambda_B 10 --lambda_identity 0.5 --load_size 286  --crop_size 256 --batch_size 1 --gpu_ids 0 --niter 100 --niter_decay 0 --display_id 0 &

#python  train.py --dataroot ./datasets/CUCK --name  CUCK220  --model attention_gan --dataset_mode aligned --pool_size 50 --no_dropout --norm instance --lambda_A 10 --lambda_B 10 --lambda_identity 0.5 --load_size 286  --crop_size 256 --batch_size 1 --gpu_ids 1 --niter 100 --niter_decay 0 --display_id 0 &&

#python  train.py --dataroot ./datasets/WHU --name  WHU220  --model attention_gan --dataset_mode aligned --pool_size 50 --no_dropout --norm instance --lambda_A 10 --lambda_B 10 --lambda_identity 0.5 --load_size 286  --crop_size 256 --batch_size 1 --gpu_ids 1 --niter 100 --niter_decay 0 --display_id 0

 
#python  train.py --dataroot ./datasets/WHU --name  WHUALCLSYSIMF  --model attention_gan --dataset_mode aligned --pool_size 50 --no_dropout --norm instance --lambda_A 10 --lambda_B 10 --lambda_identity 0.5 --load_size 286  --crop_size 256 --batch_size 1 --gpu_ids 0 --niter 100 --niter_decay 0 --display_id 0 &&

#python  train.py --dataroot ./datasets/WHU --name WHU_ALCLICS100MSFR --model attention_gan --dataset_mode aligned --pool_size 50 --no_dropout --norm instance --lambda_A 10 --lambda_B 10 --lambda_identity 0.5 --load_size 286  --crop_size 256 --batch_size 2 --gpu_ids 0,1 --niter 100 --niter_decay 0  --lambda_CS_A 15 --lambda_CS_B 1 --lambda_feat_AfA 0  --lambda_feat_BfB 0 --lambda_feat_ArecA 0  --lambda_feat_BrecB  0   --lambda_feat_fArecA 0  --lambda_feat_fBrecB 0 --lambda_syn_A  0 --lambda_syn_B  0 &&

#python  test.py --dataroot ./datasets/CUCK --name CUCK_AFR --model  attention_gan  --dataset_mode aligned --norm instance --phase test --no_dropout --load_size 286 --crop_size  256  --batch_size 1 --gpu_ids 1 --num_test 1000000000 --saveDisk &&

#python  test.py --dataroot ./datasets/AR --name AR_ALFR --model  attention_gan  --dataset_mode aligned --norm instance --phase test --no_dropout --load_size 286 --crop_size  256  --batch_size 1 --gpu_ids 1 --num_test 1000000000 --saveDisk

#python  train.py --dataroot ./datasets/WHU --name WHU_AFRL --model attention_gan --dataset_mode aligned --pool_size 50 --no_dropout --norm instance --lambda_A 10 --lambda_B 10 --lambda_identity 0.5 --load_size 286  --crop_size 256 --batch_size 1 --gpu_ids 1 --niter 200 --niter_decay 0   --lambda_CS_A 15 --lambda_CS_B 1 --lambda_feat_AfA 1  --lambda_feat_BfB 1 --lambda_feat_ArecA 1  --lambda_feat_BrecB  1   --lambda_feat_fArecA 1  --lambda_feat_fBrecB 1 --lambda_syn_A  1 --lambda_syn_B  1 &&



#python  train.py --dataroot ./datasets/WHU --name WHU_AL --model attention_gan --dataset_mode aligned --pool_size 50 --no_dropout --norm instance --lambda_A 0 --lambda_B 0 --lambda_identity 0.0 --load_size 286  --crop_size 256 --batch_size 2 --gpu_ids 0,1 --niter 200 --niter_decay 0  --lambda_CS_A 0 --lambda_CS_B 0 --lambda_feat_AfA 0  --lambda_feat_BfB 0 --lambda_feat_ArecA 0  --lambda_feat_BrecB  0   --lambda_feat_fArecA 0  --lambda_feat_fBrecB 0 --lambda_syn_A  0 --lambda_syn_B  0   &&

#python  train.py --dataroot ./datasets/WHU --name WHU_ALCL --model attention_gan --dataset_mode aligned --pool_size 50 --no_dropout --norm instance --lambda_A 10 --lambda_B 10 --lambda_identity 0.0 --load_size 286  --crop_size 256 --batch_size 2 --gpu_ids 0,1 --niter 200 --niter_decay 0   --lambda_CS_A 0 --slambda_CS_B 0 --lambda_feat_AfA 0  --lambda_feat_BfB 0 --lambda_feat_ArecA 0  --lambda_feat_BrecB  0   --lambda_feat_fArecA 0  --lambda_feat_fBrecB 0 --lambda_syn_A  0 --lambda_syn_B  0  &&
#python  train.py --dataroot ./datasets/WHU --name WHU_ALCLI --model attention_gan --dataset_mode aligned --pool_size 50 --no_dropout --norm instance --lambda_A 10 --lambda_B 10 --lambda_identity 0.5 --load_size 286  --crop_size 256 --batch_size 2 --gpu_ids 0,1 --niter 200 --niter_decay 0   --lambda_CS_A 0 --lambda_CS_B 0 --lambda_feat_AfA 0  --lambda_feat_BfB 0 --lambda_feat_ArecA 0  --lambda_feat_BrecB  0   --lambda_feat_fArecA 0  --lambda_feat_fBrecB 0 --lambda_syn_A  0 --lambda_syn_B  0   &&

#python  train.py --dataroot ./datasets/WHU --name WHU_ALCLICS --model attention_gan --dataset_mode aligned --pool_size 50 --no_dropout --norm instance --lambda_A 10 --lambda_B 10 --lambda_identity 0.5 --load_size 286  --crop_size 256 --batch_size 2 --gpu_ids 0,1 --niter 200 --niter_decay 0   --lambda_CS_A 15 --lambda_CS_B 0 --lambda_feat_AfA 0  --lambda_feat_BfB 0 --lambda_feat_ArecA 0  --lambda_feat_BrecB  0   --lambda_feat_fArecA 0  --lambda_feat_fBrecB 0 --lambda_syn_A  0 --lambda_syn_B  0  &&

#python  train.py --dataroot ./datasets/CUCK --name CUCK_ALCLICSIMWM --model attention_gan --dataset_mode aligned --pool_size 50 --no_dropout --norm instance --lambda_A 10 --lambda_B 10 --lambda_identity 0.5 --load_size 286  --crop_size 256 --batch_size 2 --gpu_ids 0,1 --niter 200 --niter_decay 0   --lambda_CS_A 15 --lambda_CS_B 1 --lambda_feat_AfA 0  --lambda_feat_BfB 0 --lambda_feat_ArecA 0  --lambda_feat_BrecB  0   --lambda_feat_fArecA 0  --lambda_feat_fBrecB 0 --lambda_syn_A  0 --lambda_syn_B  0   &&

#python  train.py --dataroot ./datasets/WHU --name WHU_ALCLICSIMWM --model attention_gan --dataset_mode aligned --pool_size 50 --no_dropout --norm instance --lambda_A 10 --lambda_B 10 --lambda_identity 0.5 --load_size 286  --crop_size 256 --batch_size 2 --gpu_ids 0,1 --niter 200 --niter_decay 0   --lambda_CS_A 15 --lambda_CS_B 1 --lambda_feat_AfA 0  --lambda_feat_BfB 0 --lambda_feat_ArecA 0  --lambda_feat_BrecB  0   --lambda_feat_fArecA 0  --lambda_feat_fBrecB 0 --lambda_syn_A  0 --lambda_syn_B  0   &&
#python  test.py --dataroot ./datasets/WHU --name WHu_ALCLICSIMWM --model  attention_gan  --dataset_mode aligned --norm instance --phase test --no_dropout --load_size 286 --crop_size  256  --batch_size 1 --gpu_ids 1 --num_test 1000000000 --saveDisk

#python  train.py --dataroot ./datasets/WHU --name WHU_ALCL --model attention_gan --dataset_mode aligned --pool_size 50 --no_dropout --norm instance --lambda_A 10 --lambda_B 10 --lambda_identity 0.5 --load_size 286  --crop_size 256 --batch_size 2 --gpu_ids 0,1 --niter 200 --niter_decay 0 --lambda_feat_fArecA 1 --lambda_feat_fBrecB 1 &&
#python  train.py --dataroot ./datasets/CUCK --name CUCK_AL --model attention_gan --dataset_mode aligned --pool_size 50 --no_dropout --norm instance --lambda_A 10 --lambda_B 10 --lambda_identity 0.5 --load_size 286  --crop_size 256 --batch_size 2 --gpu_ids 0,1 --niter 100 --niter_decay 0 &&
#python  test.py --dataroot ./datasets/WHU --name WHU_ALCL --model  attention_gan  --dataset_mode aligned --norm instance --phase test --no_dropout --load_size 286 --crop_size  256  --batch_size 1 --gpu_ids 1 --num_test 1000000000 --saveDisk #&&

#python  test.py --dataroot ./datasets/CUCK --name CUCK_AL --model  attention_gan  --dataset_mode aligned --norm instance --phase test --no_dropout --load_size 286 --crop_size  256  --batch_size 1 --gpu_ids 1 --num_test 1000000000 --saveDisk 
#python  train.py --dataroot ./datasets/WHU --name WHU_ALCLID --model  alclid --dataset_mode aligned --pool_size 50 --no_dropout --norm instance --lambda_A 10 --lambda_B 10 --lambda_identity 0.5 --load_size 286  --crop_size 256 --batch_size 1 --gpu_ids 0,1 --niter 60 --niter_decay 0  &&
#python  test.py --dataroot ./datasets/WHU --name WHU_ALCLID --model  alclid  --dataset_mode aligned --norm instance --phase test --no_dropout --load_size 286 --crop_size  256  --batch_size 1 --gpu_ids 1 --num_test 1000000000 --saveDisk
#python  train.py --dataroot ./datasets/WHU --name WHU_new565 --model attention_gan --dataset_mode aligned --pool_size 50 --no_dropout --norm instance --lambda_A 10 --lambda_B 10 --lambda_identity 0.5 --load_size 286  --crop_size 256 --batch_size 1  --gpu_ids 0,1 --niter 60 --niter_decay 0   &&
#python  test.py --dataroot ./datasets/WHU --name WHU_new565 --model attention_gan  --dataset_mode aligned --norm instance --phase test --no_dropout --load_size 286 --crop_size 256  --batch_size 1 --gpu_ids 0,1 --num_test 1000000000 --saveDisk 
#&& python  test.py --dataroot ./datasets/CUCK --name CUCK_new2 --model attention_gan  --dataset_mode aligned --norm instance --phase test --no_dropout --load_size 216 --crop_size    200 --batch_size 1 --gpu_ids 1 --num_test 1000000000 --saveDisk


