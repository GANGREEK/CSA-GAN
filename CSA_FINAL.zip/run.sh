python  train.py --dataroot ./datasets/WHU --name WHU30AL --model attention_gan --dataset_mode aligned  --batch_size 1 --gpu_ids 0 --niter 100 --niter_decay 0 --display_id 0&&

python  train.py --dataroot ./datasets/CUCK --name  CUCK30AL  --model attention_gan --dataset_mode aligned  --batch_size 1 --gpu_ids 1 --niter 100 --niter_decay 0 --display_id 0  &

python  train.py --dataroot ./datasets/AR --name  AR30AL  --model attention_gan --dataset_mode aligned  --batch_size 1 --gpu_ids 1 --niter 100 --niter_decay 0 --display_id 0


